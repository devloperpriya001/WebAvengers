<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - Real-Time Alerts</title>
    <link rel="stylesheet" href="alert.css">
</head>
<body>

<div class="container">
    <h1>Student Dashboard - Live Alerts</h1>
    <div id="alert-box">
        <p>Loading alerts...</p>
    </div>
</div>

<script>
function fetchAlerts() {
    fetch('fetch_alerts.php?type=student')
    .then(response => response.json())
    .then(data => {
        let alertBox = document.getElementById("alert-box");
        alertBox.innerHTML = "";
        data.forEach(alert => {
            alertBox.innerHTML += `<p>${alert.message} - <small>${alert.timestamp}</small></p>`;
        });
    });
}

setInterval(fetchAlerts, 5000);
fetchAlerts();
</script>

</body>
</html>
