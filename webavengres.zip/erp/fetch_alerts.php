<?php
include("db_connect.php");

$user_type = $_GET['type']; // 'faculty' or 'student'

$sql = "SELECT * FROM alerts WHERE user_type = '$user_type' ORDER BY timestamp DESC LIMIT 5";
$result = $conn->query($sql);

$alerts = [];
while ($row = $result->fetch_assoc()) {
    $alerts[] = $row;
}

echo json_encode($alerts);
?>
