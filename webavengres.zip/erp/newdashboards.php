<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Academic ERP</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Academic ERP</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        
    </div>
</nav>

<!-- Dashboard Content -->
<div class="container mt-4 text-center">
    <h1>Welcome to Academic ERP Dashboard</h1>
    <p>Manage faculty, students, reports, and performance insights efficiently.</p>

    <div class="row mt-4">
        <!-- Feature Cards -->
        <div class="col-md-3">
            <div class="card text-center shadow">
                <img src="images/grades.jpeg" class="card-img-top" alt="Faculty">
                <div class="card-body">
                    <h5 class="card-title">GRADE Management</h5>
                    <p class="card-text">Grade updates.</p>
                    <a href="submit_grades.php" class="btn btn-primary">Manage Now</a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow">
                <img src="images/Assign.jpeg" class="card-img-top" alt="Students">
                <div class="card-body">
                    <h5 class="card-title">Student assignments</h5>
                    <p class="card-text">Assignments</p>
                    <a href="faculty_assignments.php" class="btn btn-primary">View Records</a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow">
                <img src="images/report.jpeg" class="card-img-top" alt="Reports">
                <div class="card-body">
                    <h5 class="card-title">Reports & Analytics</h5>
                    <p class="card-text">Generate academic reports.</p>
                    <a href="reports.php" class="btn btn-primary">Access Reports</a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow">
                <img src="images/alert.jpeg" class="card-img-top" alt="Settings">
                <div class="card-body">
                    <h5 class="card-title">alerts</h5>
                    <p class="card-text">Manage Alerts.</p>
                    <a href="usersalert.php" class="btn btn-primary">Configure Now</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
