<?php
include("db_connect.php");

// Initialize messages
$uploadSuccess = "";
$errorMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $subject = $_POST['subject'];
    $file_name = $_FILES["assignment"]["name"];
    $file_tmp = $_FILES["assignment"]["tmp_name"];
    $file_size = $_FILES["assignment"]["size"];
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

    $allowed_extensions = ["pdf", "docx", "jpg", "png"];
    $max_file_size = 5 * 1024 * 1024; // 5MB limit

    // Validate file type & size
    if (!in_array($file_ext, $allowed_extensions)) {
        $errorMessage = "Invalid file type. Only PDF, DOCX, JPG, and PNG are allowed.";
    } elseif ($file_size > $max_file_size) {
        $errorMessage = "File size exceeds 5MB limit.";
    } else {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $target_file = $target_dir . basename($file_name);
        if (move_uploaded_file($file_tmp, $target_file)) {
            // Insert file details into database
            $sql = "INSERT INTO assignments (student_id, subject, file_name, file_path) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            if (!$stmt) {
                $errorMessage = "SQL Error: " . $conn->error;
            } else {
                $stmt->bind_param("isss", $student_id, $subject, $file_name, $target_file);
                if ($stmt->execute()) {
                    $uploadSuccess = "Assignment submitted successfully!";
                } else {
                    $errorMessage = "Error submitting assignment.";
                }
            }
        } else {
            $errorMessage = "File upload failed.";
        }
    }
}

// Fetch uploaded assignments
$result = $conn->query("SELECT student_id, subject, file_name, file_path, submission_date FROM assignments ORDER BY submission_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment Submission</title>
    <link rel="stylesheet" href="assignment.css">
</head>
<body>

<div class="assignment-container">
    <h2>Submit Your Assignment</h2>
    
    <form method="post" enctype="multipart/form-data">
        <label for="student_id">Student ID:</label>
        <input type="text" name="student_id" id="student_id" required>

        <label for="subject">Subject:</label>
        <select name="subject" id="subject" required>
            <option value="Mathematics">Mathematics</option>
            <option value="Science">Science</option>
            <option value="History">History</option>
            <option value="English">English</option>
            <option value="Computer Science">Computer Science</option>
        </select>

        <label for="assignment">Upload File:</label>
        <input type="file" name="assignment" id="assignment" required>

        <button type="submit">Submit</button>
    </form>
</div>

<div class="table-container">
    <h2>Uploaded Assignments</h2>

    <?php if ($result && $result->num_rows > 0) { ?>
        <table>
            <tr>
                <th>Student ID</th>
                <th>Subject</th>
                <th>File Name</th>
                <th>Submission Date</th>
                <th>Download</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                    <td><?php echo htmlspecialchars($row['file_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['submission_date']); ?></td>
                    <td><a href="<?php echo htmlspecialchars($row['file_path']); ?>" download>📂 Download</a></td>
                </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <p class="no-data">No assignments uploaded yet.</p>
    <?php } ?>
</div>


</body>
</html>
