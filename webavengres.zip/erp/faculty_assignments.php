<?php
include("db_connect.php");

// Fetch submitted assignments
$result = $conn->query("SELECT student_id, subject, file_name, file_path, submission_date FROM assignments ORDER BY submission_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Assignment Panel</title>
    <link rel="stylesheet" href="faculty_styles.css">
</head>
<body>



<!-- Main Assignment Content -->
<div class="container">
    <h2>Submitted Assignments</h2>

    <?php if ($result && $result->num_rows > 0) { ?>
        <table>
            <tr>
                <th>Student ID</th>
                <th>Subject</th>
                <th>File Name</th>
                <th>Submission Date</th>
                <th>Download</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                    <td><?php echo htmlspecialchars($row['file_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['submission_date']); ?></td>
                    <td><a href="<?php echo htmlspecialchars($row['file_path']); ?>" download>📂 Download</a></td>
                </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <p class="no-data">No assignments uploaded yet.</p>
    <?php } ?>
</div>

</body>
</html>
