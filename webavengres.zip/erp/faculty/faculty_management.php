<?php
// Database Connection
$servername = "localhost";
$username = "root";  // Update as per your credentials
$password = "";
$dbname = "your_database";  // Set your database name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Functions for Faculty Management
function addFaculty($name, $email, $department, $conn) {
    $stmt = $conn->prepare("INSERT INTO faculty_records (name, email, department) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $department);
    return $stmt->execute();
}

function updateFaculty($id, $name, $email, $department, $conn) {
    $stmt = $conn->prepare("UPDATE faculty_records SET name=?, email=?, department=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $email, $department, $id);
    return $stmt->execute();
}

function deleteFaculty($id, $conn) {
    $stmt = $conn->prepare("DELETE FROM faculty_records WHERE id=?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

// Handling Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add'])) {
        addFaculty($_POST['name'], $_POST['email'], $_POST['department'], $conn);
    } elseif (isset($_POST['update'])) {
        updateFaculty($_POST['id'], $_POST['name'], $_POST['email'], $_POST['department'], $conn);
    } elseif (isset($_POST['delete'])) {
        deleteFaculty($_POST['id'], $conn);
    }
}

// Fetch Faculty Records
$result = $conn->query("SELECT * FROM faculty_records");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-4">
    <h2>Faculty Record Management</h2>
    
    <!-- Add Faculty Form -->
    <form method="POST" class="mb-4">
        <input type="text" name="name" placeholder="Faculty Name" required class="form-control mb-2">
        <input type="email" name="email" placeholder="Email" required class="form-control mb-2">
        <input type="text" name="department" placeholder="Department" required class="form-control mb-2">
        <button type="submit" name="add" class="btn btn-primary">Add Faculty</button>
    </form>

    <!-- Faculty Records Table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['department'] ?></td>
                    <td>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <input type="text" name="name" value="<?= $row['name'] ?>" required class="form-control mb-2">
                            <input type="email" name="email" value="<?= $row['email'] ?>" required class="form-control mb-2">
                            <input type="text" name="department" value="<?= $row['department'] ?>" required class="form-control mb-2">
                            <button type="submit" name="update" class="btn btn-warning">Update</button>
                        </form>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <button type="submit" name="delete" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>

<?php $conn->close(); ?>
