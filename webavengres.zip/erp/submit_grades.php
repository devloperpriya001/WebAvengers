<?php
session_start();
include("db_connect.php");

// Fetch students dynamically
$students_result = $conn->query("SELECT id, username FROM users"); // Using `users` table instead of `students`

$successMessage = "";
$errorMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = trim($_POST['student_id']);
    $subject = trim($_POST['subject']);
    $grade = trim($_POST['grade']);
    $feedback = trim($_POST['feedback']);

    // Validate input fields
    if (empty($student_id) || empty($subject) || empty($grade)) {
        $errorMessage = "Error: All fields are required.";
    } else {
        // Prepare statement to prevent SQL injection
        $sql = "INSERT INTO grades (user_id, subject, grade, feedback) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isss", $student_id, $subject, $grade, $feedback);

        if ($stmt->execute()) {
            $successMessage = "Grade submitted successfully!";
        } else {
            $errorMessage = "Error submitting grade: " . $conn->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Grades</title>
    <link rel="stylesheet" href="grade.css">
</head>
<body>

    <h2>Teacher Grade Submission</h2>

    <!-- Display messages -->
    <?php if (!empty($successMessage)) { echo "<p class='success'>$successMessage</p>"; } ?>
    <?php if (!empty($errorMessage)) { echo "<p class='error'>$errorMessage</p>"; } ?>

    <form method="post">
        <label>Student:</label>
        <select name="student_id" required>
            <option value="">Select a student</option>
            <?php while ($row = $students_result->fetch_assoc()) { ?>
                <option value="<?php echo $row['id']; ?>">
                    <?php echo htmlspecialchars($row['username']); ?>
                </option>
            <?php } ?>
        </select>

        <label>Subject:</label>
        <select name="subject" required>
            <option value="">Select a subject</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Science">Science</option>
            <option value="History">History</option>
            <option value="English">English</option>
            <option value="Computer Science">Computer Science</option>
        </select>

        <label>Grade:</label>
        <select name="grade" required>
            <option value="">Select a grade</option>
            <option value="A+">A+</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
            <option value="F">F</option>
        </select>

        <label>Feedback:</label>
        <textarea name="feedback" rows="3"></textarea>

        <button type="submit">Submit Grade</button>
    </form>

</body>
</html>
