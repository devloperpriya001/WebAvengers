<?php
session_start();
include "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $role = trim($_POST["role"]);

    if (empty($username) || empty($email) || empty($password) || empty($role)) {
        die("<script>alert('Error: All fields are required.'); window.location.href='signup.html';</script>");
    }

    // Secure password hashing
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if username or email already exists
    $check_stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $check_stmt->bind_param("ss", $username, $email);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        die("<script>alert('Error: Username or Email already exists.'); window.location.href='signup.html';</script>");
    }
    $check_stmt->close();

    // Insert user data into database with role
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $email, $hashed_password, $role);

    if ($stmt->execute()) {
        $_SESSION["user_id"] = $stmt->insert_id;
        $_SESSION["username"] = $username;
        $_SESSION["role"] = $role;

        // Redirect users to respective dashboards
        if ($role == "admin") {
            header("Location: admindashboard.html");
        } elseif ($role == "faculty") {
            header("Location: newdashboards.php");
        } else {
            header("Location: dashboards.php");
        }
        exit();
    } else {
        die("<script>alert('Error registering user.'); window.location.href='signup.html';</script>");
    }

    $stmt->close();
}
?>
