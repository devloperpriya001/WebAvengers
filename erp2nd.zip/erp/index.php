<?php
session_start();

// Redirect user to login page if not logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit();
}
