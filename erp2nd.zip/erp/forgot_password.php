<?php
include "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $token = bin2hex(random_bytes(50)); // Secure random token

    $stmt = $conn->prepare("UPDATE users SET reset_token = ? WHERE email = ?");
    $stmt->bind_param("ss", $token, $email);
    if ($stmt->execute()) {
        // Send reset link via email
        $reset_link = "http://yourwebsite.com/reset_password.php?token=" . $token;
        mail($email, "Password Reset Request", "Click here to reset your password: $reset_link");
        
        echo "Password reset link sent to your email!";
    } else {
        echo "Error! Email not found.";
    }
}
?>
