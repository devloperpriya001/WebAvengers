<?php
session_start();
include "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $role = trim($_POST["role"]);

    if (empty($username) || empty($password) || empty($role)) {
        die("<script>alert('Error: All fields are required.'); window.location.href='login.html';</script>");
    }

    // Fetch user details based on role
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ? AND role = ?");
    $stmt->bind_param("ss", $username, $role);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $hashed_password);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashed_password)) {
            $_SESSION["user_id"] = $user_id;
            $_SESSION["username"] = $username;
            $_SESSION["role"] = $role;

            // Redirect based on role
            if ($role == "admin") {
                header("Location: admindashboard.php");
            } elseif ($role == "faculty") {
                header("Location: exfacultydashboard.php");
            } else {
                header("Location: student_dashboard.php");
            }
            exit();
        } else {
            echo "<script>alert('Error: Incorrect password.'); window.location.href='login.html';</script>";
        }
    } else {
        echo "<script>alert('Error: User not found.'); window.location.href='login.html';</script>";
    }

    $stmt->close();
}
?>
