<?php
session_start();
include("db_connect.php");

// Ensure user is logged in
if (!isset($_SESSION["user_id"])) {
    die("<script>alert('Error: Please log in first.'); window.location.href='login.php';</script>");
}

// Get logged-in user's ID
$user_id = $_SESSION["user_id"];

// Fetch grades from `grades` table linked to `users`
$result = $conn->query("SELECT subject, grade, feedback, date FROM grades WHERE user_id = '$user_id'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Grades</title>
    <link rel="stylesheet" href="grade.css">
</head>
<body>

    <h2>Your Grades</h2>

    <?php if ($result->num_rows > 0) { ?>
        <table>
            <tr>
                <th>Subject</th>
                <th>Grade</th>
                <th>Feedback</th>
                <th>Date</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                    <td><?php echo htmlspecialchars($row['grade']); ?></td>
                    <td><?php echo htmlspecialchars($row['feedback']); ?></td>
                    <td><?php echo htmlspecialchars($row['date']); ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <p class="no-data">No grades available yet.</p>
    <?php } ?>

</body>
</html>
