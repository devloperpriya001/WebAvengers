<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic ERP</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success">
        <div class="container">
            <a class="navbar-brand" href="#">Academic ERP</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="attendance.php"></a></li>
                    <li class="nav-item"><a class="nav-link" href="assignments.php"></a></li>
                    <li class="nav-item"><a class="nav-link" href="grade_tracking.php"></a></li>
                    <li class="nav-item"><a class="nav-link" href="library.php"></a></li>
                    
                    <!-- User Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            👤 Profile
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="settings.php">Settings</a></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Home Page Content with Feature Cards -->
    <div class="container mt-4 text-center">
        <h1>Welcome to Academic ERP</h1>
        <p>Manage attendance, assignments, grades, and more efficiently.</p>
        
        <div class="row mt-4">
            <!-- Feature Cards -->
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <img src="images/attendance.jpg" class="card-img-top" alt="Attendance">
                    <div class="card-body">
                        <h5 class="card-title">Attendance Tracking</h5>
                        <p class="card-text">Automated face-recognition-based attendance system.</p>
                        <a href="attendance.php" class="btn btn-success">Access Now</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card text-center shadow">
                    <img src="images/assignments.jpg" class="card-img-top" alt="Assignments">
                    <div class="card-body">
                        <h5 class="card-title">Assignment Submission</h5>
                        <p class="card-text">Submit assignments, track deadlines, and receive feedback.</p>
                        <a href="submit_assignment.php" class="btn btn-success">Upload Now</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card text-center shadow">
                    <img src="images/grades.jpg" class="card-img-top" alt="Grades">
                    <div class="card-body">
                        <h5 class="card-title">Grade Tracking</h5>
                        <p class="card-text">Monitor academic progress and performance insights.</p>
                        <a href="grade_tracking.php" class="btn btn-success">View Grades</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card text-center shadow">
                    <img src="images/library.jpg" class="card-img-top" alt="Library">
                    <div class="card-body">
                        <h5 class="card-title">Library Management</h5>
                        <p class="card-text">Explore books, borrow online, and track returns.</p>
                        <a href="library.php" class="btn btn-success">Visit Library</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
